#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
const int M = 105;
int mp[M][M];
int color[M];
int col = 1, n, m;
FILE* fp1;
FILE* fp2;
int Check(int k)
{
	for (int i = 1; i <= k; i++)
	{
		if (mp[k][i] == 1 && color[i] == color[k])
			return 0;
	}
	return 1;
}
int num(int col)//���ټ�����ɫ
{
	for (int i = 1; i <= n; i++)
	{
		int flag = 0;
		for (int j = 1; j <= col; j++)
		{
			color[i] = j;
			if (Check(i) == 1)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			col++;
			color[i] = col;
		}
	}
	return col;
}
void Color(int step)
{
	if (step == n + 1)  
	{
		for (int i = 1; i <= n; i++)
			printf("%d ", color[i]);
		printf("\n");
		return;
	}
	else
	{
		for (int i = 1; i <= col; i++)
		{
			color[step] = i; 
			if (Check(step) == 1)
			{
				Color(step + 1);
			}
			color[step] = 0; 
		}
	}
}

int main(void)
{
	cin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		int u, v;
		cin >> u >> v;
		mp[u][v] = 1;
		mp[v][u] = 1;
	}
	col = num(1);
	memset(mp, 0, sizeof(color));
	Color(1);
	return 0;
}
