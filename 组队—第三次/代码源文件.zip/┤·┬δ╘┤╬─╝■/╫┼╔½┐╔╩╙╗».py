import networkx as nx
import matplotlib.pyplot as plt

file_read = open('图着色（贪心法）\图着色（贪心法）\mp.txt', 'r')
file_color = open('图着色（贪心法）\图着色（贪心法）\color.txt', 'r')
try:
     matrix = [[0 for x in range(105)] for y in range(105)]
     m = 0
     for line in file_read:
          matrix[m] = line.split(' ')
          m = m + 1
     G = nx.Graph()
     v = range(0, m)
     G.add_nodes_from(v)
     line = file_color.read()
     colors = (line.split(' '))
     for i in range(len(colors)):
         colors[i] = int(colors[i])
     for x in range(0, m):
          for y in range(0, m):
               if matrix[x][y] == '1':
                    G.add_edge(x, y)
     nx.draw(G, with_labels=True, node_color=colors)
     plt.show()
finally:
     file_read.close()