#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
const int M = 105;
int mp[M][M];
int color[M];
int col = 0, n, m;
FILE* fp1;
FILE* fp2;
int Check(int k)
{
	for (int i = 1; i <= k; i++)
	{
		if (mp[k][i] == 1 && color[i] == color[k])
			return 0;
	}
	return 1;
}
void Color()
{
	int flag = 1;
	while (flag)//��Ҫ����ɫ
	{
		col++;
		flag = 0;
		for (int i = 1; i <= n; i++)
		{
			if (color[i] == 0)
			{
				color[i] = col;
				if (Check(i) == 0)
				{
					color[i] = 0;
					flag = 1;
				}
			}
		}
	}
	for (int i = 1; i <= n; i++)
		cout << color[i] << " ";
	cout << endl;
}
int main()
{
	fp1 = fopen("mp.txt", "wb");
	fp2 = fopen("color.txt", "wb");
	cin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		int u, v;
		cin >> u >> v;
		mp[u][v] = 1;
		mp[v][u] = 1;
	}
	Color();
	cout << col;
	cout << endl;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
			fprintf(fp1, "%d ", mp[i][j]);
		fprintf(fp1, "\n");
	}
	for (int i = 1; i < n; i++)
		fprintf(fp2, "%d ", color[i]);
	fprintf(fp2, "%d", color[n]);
	return 0;
}