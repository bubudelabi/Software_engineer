#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
const int M = 105;
int mp[M][M];
int color[M];
int col = 1, n, m;
FILE* fp1;
FILE* fp2;
int Check(int k)
{
	for (int i = 1; i <= k; i++)
	{
		if (mp[k][i] == 1 && color[i] == color[k])
			return 0;
	}
	return 1;
}

void Color()
{
	for (int i = 1; i <= n; i++)
	{
		int flag = 0;
		for (int j = 1; j <= col; j++)
		{
			color[i] = j;
			if (Check(i) == 1)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			col++;
			color[i] = col;
		}
	}
	for (int i = 1; i <= n; i++)
		cout << color[i] << " ";
	cout << endl;
}

int main(void)
{
	fp1 = fopen("mp.txt", "wb");
	fp2 = fopen("color.txt", "wb");
	cin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		int u, v;
		cin >> u >> v;
		mp[u][v] = 1;
		mp[v][u] = 1;
	}
	Color();
	cout << col;
	cout << endl;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
			fprintf(fp1, "%d ", mp[i][j]);
		fprintf(fp1, "\n");
	}
	for (int i = 1; i < n; i++)
		fprintf(fp2, "%d ", color[i]);
	fprintf(fp2, "%d", color[n]);
	return 0;
}
